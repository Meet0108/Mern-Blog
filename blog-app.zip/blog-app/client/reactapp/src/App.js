import React, { useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import CreateBlog from './pages/CreateBlog';
import AboutUs from './pages/AboutUs';
import BlogDetails from './pages/BlogDetails';

const App = () => {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <Layout onSearch={setSearchTerm}>
      <Routes>
        <Route path="/" element={<Home searchTerm={searchTerm} />} />
        <Route path="/create" element={<CreateBlog />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/blogs/:id" element={<BlogDetails />} />
      </Routes>
    </Layout>
  );
};

export default App;
