import React from 'react';
import Header from './Header';
import Footer from './Footer';

const Layout = ({ children, onSearch }) => (
  <div>
    <Header onSearch={onSearch} />
    <main className="container mt-4">
      {children}
    </main>
    <Footer />
  </div>
);

export default Layout;
