import React from "react";

const AboutUs = () => (
  <>
    <div class="container">
      <h1 class="display-4 text-center">About Us</h1>
    </div>
    <div class="container pt-5">
      <div class="row justify-content-center align-items-center ">
        <div class="col-md-6">
          <img
            src="https://findbestcourses.com/wp-content/uploads/2022/08/Blogging.png"
            class="img-fluid rounded-top"
            alt=""
          />
        </div>
        <div class="col">
          <h1 class="display-6">
            <strong>Who We Are</strong>
          </h1>
          <p class="lead">
            We are a team of passionate bloggers who love to share our knowledge
            and experiences with others. We believe that everyone has something
            valuable to contribute to the world, and we want to help people
            discover and share their unique voices. Our mission is to create a
            community of bloggers who can <strong>inspire</strong>,
            <strong>educate</strong>, and <strong>entertain</strong> others
            through their writing. We hope that by sharing our stories and
            experiences, we can help others find their own voice and
            <strong>make a difference</strong> in the world.
          </p>
        </div>
      </div>
    </div>
  </>
);

export default AboutUs;
