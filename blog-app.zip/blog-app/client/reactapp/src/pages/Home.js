import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getBlogs } from "../services/blogService";
import "../style.css";

const Home = ({ searchTerm }) => {
  const [blogs, setBlogs] = useState([]);

  useEffect(() => {
    const fetchBlogs = async () => {
      const response = await getBlogs();
      setBlogs(response.data);
    };
    fetchBlogs();
  }, []);

  const filteredBlogs = blogs.filter(
    (blog) =>
      blog.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      blog.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <div className="heading text-center">
        <marquee>
          {" "}
          <h1>Welcome To My Blog !!</h1>
        </marquee>
      </div>

      <div className="row justify-content-center align-items-center border-top py-5">
        {filteredBlogs.map((blog) => (
          <div className="col-md-4 mb-4" key={blog._id}>
            <div className="card fixed-size-card">
              <img
                src={blog.image}
                className="card-img-top fixed-size-img"
                alt={blog.title}
              />
              <div className="card-body">
                <h5 className="card-title">{blog.title}</h5>
                <p className="card-text">{blog.content.substring(0, 100)}...</p>
                <Link to={`/blogs/${blog._id}`} className="btn btn-primary">
                  Read More
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default Home;
