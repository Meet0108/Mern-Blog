import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getBlog, deleteBlog, updateBlog } from "../services/blogService";

const BlogDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [blog, setBlog] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    image: "",
    content: "",
  });

  useEffect(() => {
    const fetchBlog = async () => {
      const response = await getBlog(id);
      setBlog(response.data);
      setFormData(response.data);
    };
    fetchBlog();
  }, [id]);

  const handleDelete = async () => {
    try {
      await deleteBlog(id);
      navigate("/");
    } catch (error) {
      console.error("Failed to delete the blog", error);
    }
  };

  const handleUpdate = async () => {
    try {
      await updateBlog(id, formData);
      setIsEditing(false);
      const response = await getBlog(id);
      setBlog(response.data);
    } catch (error) {
      console.error("Failed to update the blog", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  if (!blog) return <p>Loading...</p>;

  return (
    <div>
      {isEditing ? (
        <div>
          <h2 className="text-center">Edit Blog</h2>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleUpdate();
            }}
          >
            <div className="form-group">
              <label>Title</label>
              <input
                type="text"
                className="form-control"
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Image URL</label>
              <input
                type="text"
                className="form-control"
                name="image"
                value={formData.image}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Content</label>
              <textarea
                className="form-control"
                name="content"
                value={formData.content}
                onChange={handleChange}
                required
              ></textarea>
            </div>
            <button type="submit" className="btn btn-primary mt-2">
              Update
            </button>
            <button
              type="button"
              className="btn btn-secondary mt-2 ms-2"
              onClick={() => setIsEditing(false)}
            >
              Cancel
            </button>
          </form>
        </div>
      ) : (
        <div>
          <div class="row justify-content-center align-items-center g-2 pt-5">
            <div class="col-md-4">
              <div class="container fixed-column">
                <img src={blog.image} alt={blog.title} className="img pt-2" />
              </div>
            </div>
            <div class="  col">
              
              <div class="container scrollable-column">
                <h2 className="text-center">{blog.title}</h2>

                <p className=" pt-2">{blog.content}</p>
                <button className="btn btn-danger" onClick={handleDelete}>
                  Delete
                </button>
                <button
                  className="btn btn-primary ms-4"
                  onClick={() => setIsEditing(true)}
                >
                  Edit
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BlogDetails;
