import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:5000/api',
});

export const getBlogs = () => api.get('/blogs');
export const getBlog = (id) => api.get(`/blogs/${id}`);
export const createBlog = (blog) => api.post('/blogs', blog);
export const updateBlog = (id, blog) => api.put(`/blogs/${id}`, blog);
export const deleteBlog = (id) => api.delete(`/blogs/${id}`);
